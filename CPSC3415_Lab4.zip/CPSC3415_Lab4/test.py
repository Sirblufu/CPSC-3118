def myFunc:
    print 'Hello'

myFunc