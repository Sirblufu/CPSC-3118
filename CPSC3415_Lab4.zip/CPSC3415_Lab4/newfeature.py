def myFunc:
    print('Hello new feature')

    print('Additional work')

    print('We meet again')


myFunc